from scipy import optimize
import numpy as np
import torch.nn as nn
import torch
from deep_d import SimpleNet
from fit_d import gen_d_vector
import numpy as np
import matplotlib.pyplot as plt

def f(guess):
    guess_ds = gen_d_vector(*guess)
    return np.linalg.norm(guess_ds - gen_d_vector(*known_params))

if __name__ == "__main__":
    model = SimpleNet()
    model.load_state_dict(torch.load("model.pth"))
    model.eval()
    known_params = np.array([0.65, 1.2, np.radians(111)]) # Only used for comparison later
    input_d = gen_d_vector(*known_params)
    guess = model(torch.Tensor(input_d).unsqueeze(0)).detach().numpy()
    result = optimize.minimize(f, guess, options={'disp': True})
    print(result.x)
    print(known_params)

    actual_qs = 1 / gen_d_vector(*known_params)
    pred_qs = 1 / gen_d_vector(*result.x)
    plt.scatter(actual_qs, [0.5] * len(actual_qs))
    for q in pred_qs:
        plt.axvline(x=q)
    plt.show()