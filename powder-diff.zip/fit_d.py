import numpy as np
from sklearn.neural_network import MLPRegressor
from matplotlib import pyplot as plt
from scipy.optimize import basinhopping
from sklearn import preprocessing
from scipy.stats import truncnorm
import math

import torch.nn as nn
import cProfile, pstats, io
from pstats import SortKey
pr = cProfile.Profile()


#TODO: VECTORIZE!
def create_d_generator(a,b,gamma):
    top = np.sin(gamma)
    t1 = a ** 2
    t2 = b ** 2
    t3 = 2 * np.cos(gamma) / (a*b)
    def f(H, K):
        return top / math.sqrt(H**2 / t1 + K**2 / t2 - H*K*t3)
    return f

def gen_d(a,b,gamma,H,K):
    return np.sin(gamma) / np.sqrt(H**2/a**2 + K**2/b**2 - 2*H*K*np.cos(gamma) / (a*b))

def create_vec_generator(H_max=10, K_max=10, noise=0, dropout=False):
    """
    Returns a function that generates a Torch tensor of the vectors.
    Pydoc will create pretty documentation based off these docstrings.
    :param H_max: The maximum |H| to search over when generating d-spacings
    :param K_max: The maximum |K| to search over when generating d-spacings
    :param noise: Range of truncated normal, which will have range [-noise, noise].  Set to zero to disable addition of random noise.  #TODO: make this normally distributed with SD noise
    :param dropout: If True, then length of output vector will be truncated with 50% probability
    :return: A function f(a,b,gamma) that returns an array of the 5 highest d-spacings over the given H_max, K_max range for the given parameters.
    """
    if noise:
        t = truncnorm(-noise, noise)
        #noise_amt = (1-t.rvs(1)[0])
    def f(a,b, gamma):

        #pr.enable()
        d_generator = create_d_generator(a,b,gamma)
        temp = np.zeros(2 * H_max * K_max)
        #temp2 = np.zeros(2 * H_max * K_max)
        i = 0
        # gaussian = np.random.normal(1, noise)
        for H in range(-H_max, H_max):
            for K in range(0, H + 1):
                if H == 0 and K == 0:
                    continue
                #d = gen_d(a, b, gamma, H, K)
                d = d_generator(H,K)
                temp[i] = d
                i += 1
        indices = np.argsort(temp[temp != 0])[:8]
        if noise:
            noise_arr = 1 - t.rvs(8)
        else:
            noise_arr = 1
            #return np.array(temp[indices]) * noise_arr

        if dropout:
            out = np.array(temp[indices])
            if np.random.randint(2):
                start = np.random.randint(15, 30)
                out[start:] = 0#-5
            return out * noise_arr
        else:
            return np.array(temp[indices]) * noise_arr

    return f


def gen_d_vector(a,b,gamma,H_max=10, K_max=10, noise=0, dropout=False):
    temp = np.zeros(2*H_max*K_max)
    temp2 = np.zeros(2*H_max*K_max)
    i=0
    #gaussian = np.random.normal(1, noise)
    if noise:
        t = truncnorm(-noise, noise)
        noise_amt = (1-t.rvs(1)[0])
    for H in range(-H_max, H_max):
        for K in range(0, H+1):
            if H == 0 and K == 0:
                continue
            d = gen_d(a, b, gamma, H, K)
            #if noise:
            #    temp2[i] = d * noise_amt
            #else:
            #    temp2[i] = d
            if noise:
                temp2 *= noise_amt
            temp[i] = d
            i+=1
    indices = np.argsort(temp[temp != 0])[:5]#:30
    if dropout:
        out = np.array(temp[indices])
        if True: #np.random.randint(2):
            start = np.random.randint(15,30)
            out[start:] = 0 #-5
        return out
    else:
        return np.array(temp[indices])

def gen_input(n):
    #a: 0.3-1.5
    #b: 0.5-2.5
    #gamma: 85-130
    #return [gen_d_vector(np.random.random(), np.random.random(), np.random.random()*50, 10, 10) for x in range(n)]
    return [[np.random.random()*1.2+0.3, np.random.random()*2+0.5, np.radians(85+np.random.random() * (130-85))] for x in range(n)]



if __name__ == '__main__':

    xs = np.array([])
    ys = np.array([])
    a = 0.65
    b = 1.2
    g = np.radians(111)
    for M in range(-3, 3):
        for N in range(-3, 3):
            #if M == 0 and N == 0:
            #    continue
            xs = np.append(xs, M*a + N*b*np.cos(g))
            ys = np.append(ys, N*b*np.sin(g))

    plt.scatter(xs, ys)
    plt.scatter(xs+1, ys)
    plt.show()
